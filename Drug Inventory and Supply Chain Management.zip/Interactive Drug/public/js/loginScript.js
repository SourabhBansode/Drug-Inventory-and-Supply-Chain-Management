document.addEventListener('DOMContentLoaded', function () {
    const API_URL = '/api';

    const toast = document.querySelector('.toast');
function showToast(message) {
    toast.textContent = message;
    toast.style.display = 'block';
    toast.style.opacity = '1';
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 300); // Match the animation duration
    }, 3000); // Display for 3 seconds
}

    // Password visibility toggle
    document.querySelectorAll('.password-toggle').forEach(toggle => {
        toggle.addEventListener('click', function () {
            const passwordField = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });

    // Form validation and submission
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();

            if (!email || !password) {
                showToast('Please fill in all fields', 'error');
                return;
            }

            if (!isValidEmail(email)) {
                showToast('Please enter a valid email address', 'error');
                return;
            }

            try {
                const response = await fetch(`${API_URL}/users/login`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                if (response.ok && data.token) {
                    // Clear any existing user data
                    localStorage.clear();
                    sessionStorage.clear();

                    // Store new user data
                    localStorage.setItem('token', data.token);
                    localStorage.setItem('user', JSON.stringify(data.user));
                    
                    // Handle remember me
                    const rememberMe = document.getElementById('remember').checked;
                    if (rememberMe) {
                        localStorage.setItem('pharmaflow_remember', 'true');
                        localStorage.setItem('pharmaflow_email', email);
                    }

                    showToast('Login successful! Redirecting...', 'success');
                    
                    // Redirect with token
                    setTimeout(() => {
                        window.location.href = `/dashboard?token=${data.token}`;
                    }, 1500);
                } else {
                    showToast(data.message || 'Invalid credentials', 'error');
                }
            } catch (error) {
                console.error('Login error:', error);
                showToast('Login failed. Please try again.', 'error');
            }
        });
    }

    // Input focus effects (icons & placeholders)
    document.querySelectorAll(".input-with-icon input").forEach(input => {
        const icon = input.closest('.input-with-icon').querySelector('i');

        input.addEventListener("focus", function () {
            if (icon) icon.style.opacity = "0";
            this.dataset.placeholder = this.placeholder;
            this.placeholder = "";
        });

        input.addEventListener("blur", function () {
            if (icon) icon.style.opacity = this.value ? "0" : "1";
            if (!this.value.trim()) {
                this.placeholder = this.dataset.placeholder;
            }
        });
    });

    // Remember me functionality
    const rememberCheckbox = document.getElementById('remember');
    if (rememberCheckbox) {
        if (localStorage.getItem('pharmaflow_remember') === 'true') {
            rememberCheckbox.checked = true;
            const savedEmail = localStorage.getItem('pharmaflow_email');
            if (savedEmail) document.getElementById('email').value = savedEmail;
        }
    }

    // Helper function
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
});
