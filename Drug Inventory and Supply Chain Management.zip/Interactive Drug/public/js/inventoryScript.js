document.addEventListener('DOMContentLoaded', async function() {
    // Set current date
    const currentDate = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('current-date').textContent = currentDate.toLocaleDateString('en-US', options);
    
    let inventoryData = [];
    let drugToDelete = null;

    // Fetch inventory data from API
    async function fetchInventoryData() {
        try {
            const response = await fetch('/api/medicines');
            if (!response.ok) {
                throw new Error('Failed to fetch inventory data');
            }
            const data = await response.json();
            inventoryData = data;
            updateOverviewCards(inventoryData);
            initInventoryTable(inventoryData);
        } catch (error) {
            console.error('Error:', error);
            showToast('error', 'Error', 'Failed to load inventory data');
        }
    }

    // Update overview cards
    function updateOverviewCards(data) {
        const totalProducts = data.length;
        const lowStockItems = data.filter(item => item.stock <= item.threshold).length;
        const expiringItems = data.filter(item => {
            const expiryDate = new Date(item.expiryDate);
            const thirtyDaysFromNow = new Date();
            thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
            return expiryDate <= thirtyDaysFromNow;
        }).length;
        const inStockItems = data.filter(item => item.stock > 0).length;

        const overviewValues = document.querySelectorAll('.overview-value');
        if (overviewValues.length >= 4) {
            overviewValues[0].textContent = totalProducts;
            overviewValues[1].textContent = lowStockItems;
            overviewValues[2].textContent = expiringItems;
            overviewValues[3].textContent = inStockItems;
        }
    }

    // Initialize inventory table
    function initInventoryTable(data) {
        const tableBody = document.getElementById('inventory-table-body');
        if (!tableBody) return;
    
        tableBody.innerHTML = '';
        
        if (data.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="8" class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>No drugs found. Try adjusting your filters or add a new drug.</p>
                    </td>
                </tr>
            `;
            return;
        }
    
        data.forEach(drug => {
            const row = document.createElement('tr');
            const expiryDate = new Date(drug.expiryDate);
            const isExpiringSoon = expiryDate <= new Date(Date.now() + (30 * 24 * 60 * 60 * 1000));
            const stockStatus = drug.stock === 0 ? 'Out of Stock' : 
                              drug.stock <= drug.threshold ? 'Low Stock' : 'In Stock';
            const statusClass = drug.stock === 0 ? 'danger' : 
                              drug.stock <= drug.threshold ? 'warning' : 'success';
            
            row.innerHTML = `
                <td>
                    <div class="drug-info">
                        <span class="drug-name">${drug.name}</span>
                        <span class="drug-id">#${drug._id}</span>
                    </div>
                </td>
                <td>${drug.category || 'N/A'}</td>
                <td>
                    <div class="stock-info ${drug.stock <= drug.threshold ? 'warning' : ''}">
                        ${drug.stock} ${drug.unit}
                    </div>
                </td>
                <td>${drug.unit || 'N/A'}</td>
                <td class="${isExpiringSoon ? 'expiring' : ''}">${new Date(drug.expiryDate).toLocaleDateString()}</td>
                <td>${drug.supplier || 'N/A'}</td>
                <td>
                    <span class="status-badge ${statusClass}">
                        ${stockStatus}
                    </span>
                </td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn-icon edit-drug" data-id="${drug._id}" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-icon delete-drug" data-id="${drug._id}" data-name="${drug.name}" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            `;

            // Add event listeners for edit and delete buttons
            const editBtn = row.querySelector('.edit-drug');
            const deleteBtn = row.querySelector('.delete-drug');

            editBtn.addEventListener('click', () => editDrug(drug));
            deleteBtn.addEventListener('click', () => {
                drugToDelete = {
                    id: drug._id,
                    name: drug.name
                };
                document.getElementById('delete-drug-name').textContent = drug.name;
                document.getElementById('delete-modal').classList.add('active');
            });

            tableBody.appendChild(row);
        });

        // Update pagination info
        const totalItems = document.getElementById('total-items');
        const showingStart = document.getElementById('showing-start');
        const showingEnd = document.getElementById('showing-end');

        if (totalItems) totalItems.textContent = data.length;
        if (showingStart) showingStart.textContent = data.length > 0 ? '1' : '0';
        if (showingEnd) showingEnd.textContent = data.length;
    }

    // Edit drug function
    function editDrug(drug) {
        const drugModal = document.getElementById('drug-modal');
        document.getElementById('modal-title').textContent = 'Edit Drug';
        document.getElementById('drug-id').value = drug._id;
        document.getElementById('drug-name').value = drug.name;
        document.getElementById('drug-category').value = drug.category;
        document.getElementById('drug-stock').value = drug.stock;
        document.getElementById('drug-unit').value = drug.unit;
        document.getElementById('drug-expiry').value = drug.expiryDate.split('T')[0];
        document.getElementById('drug-supplier').value = drug.supplier;
        document.getElementById('drug-threshold').value = drug.threshold;
        document.getElementById('drug-price').value = drug.price;
        document.getElementById('drug-description').value = drug.description || '';
        
        drugModal.classList.add('active');
    }

    // Initialize event listeners
    const drugModal = document.getElementById('drug-modal');
    const deleteModal = document.getElementById('delete-modal');
    const drugForm = document.getElementById('drug-form');

    // Add Drug Button
    document.getElementById('add-drug-btn')?.addEventListener('click', () => {
        drugForm.reset();
        document.getElementById('drug-id').value = '';
        document.getElementById('modal-title').textContent = 'Add New Drug';
        drugModal.classList.add('active');
    });

    // Modal close buttons
    document.getElementById('close-modal')?.addEventListener('click', () => drugModal.classList.remove('active'));
    document.getElementById('cancel-drug')?.addEventListener('click', () => drugModal.classList.remove('active'));
    document.getElementById('close-delete-modal')?.addEventListener('click', () => deleteModal.classList.remove('active'));
    document.getElementById('cancel-delete')?.addEventListener('click', () => deleteModal.classList.remove('active'));

    // Save drug
    document.getElementById('save-drug')?.addEventListener('click', async () => {
        if (!drugForm.checkValidity()) {
            drugForm.reportValidity();
            return;
        }

        const drugId = document.getElementById('drug-id').value;
        const drugData = {
            name: document.getElementById('drug-name').value.trim(),
            category: document.getElementById('drug-category').value,
            stock: parseInt(document.getElementById('drug-stock').value) || 0,
            unit: document.getElementById('drug-unit').value,
            expiryDate: document.getElementById('drug-expiry').value,
            supplier: document.getElementById('drug-supplier').value,
            threshold: parseInt(document.getElementById('drug-threshold').value) || 0,
            price: parseFloat(document.getElementById('drug-price').value) || 0,
            description: document.getElementById('drug-description').value.trim()
        };

        try {
            const url = drugId ? `/api/medicines/${drugId}` : '/api/medicines';
            const method = drugId ? 'PUT' : 'POST';
            
            console.log('Sending data:', drugData); // Debug log

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(drugData)
            });

            const responseData = await response.json();
            console.log('Server response:', responseData); // Debug log

            if (!response.ok) {
                throw new Error(responseData.message || 'Failed to save drug');
            }

            await fetchInventoryData();
            showToast('success', 'Success', `Drug ${drugId ? 'updated' : 'added'} successfully`);
            drugModal.classList.remove('active');
        } catch (error) {
            console.error('Error details:', error);
            showToast('error', 'Error', error.message || 'Failed to save drug');
        }
    });

    // Delete drug
    document.getElementById('confirm-delete')?.addEventListener('click', async () => {
        if (!drugToDelete?.id) {
            showToast('error', 'Error', 'Invalid drug ID');
            deleteModal.classList.remove('active');
            return;
        }

        try {
            const response = await fetch(`/api/medicines/${drugToDelete.id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to delete drug');
            }

            await fetchInventoryData();
            showToast('success', 'Success', `${drugToDelete.name} has been deleted`);
        } catch (error) {
            console.error('Error:', error);
            showToast('error', 'Error', 'Failed to delete drug');
        }
        deleteModal.classList.remove('active');
        drugToDelete = null;
    });

    // Search and filter functionality
    const searchInput = document.getElementById('drug-search');
    const categoryFilter = document.getElementById('category-filter');
    const statusFilter = document.getElementById('status-filter');
    const sortBy = document.getElementById('sort-by');

    function applyFilters() {
        let filtered = [...inventoryData];

        // Apply search filter
        const searchTerm = searchInput.value.toLowerCase();
        if (searchTerm) {
            filtered = filtered.filter(drug => 
                drug.name.toLowerCase().includes(searchTerm) ||
                drug.category.toLowerCase().includes(searchTerm) ||
                drug.supplier.toLowerCase().includes(searchTerm)
            );
        }

        // Apply category filter
        if (categoryFilter.value !== 'all') {
            filtered = filtered.filter(drug => drug.category === categoryFilter.value);
        }

        // Apply status filter
        if (statusFilter.value !== 'all') {
            filtered = filtered.filter(drug => {
                const expiryDate = new Date(drug.expiryDate);
                switch (statusFilter.value) {
                    case 'in-stock':
                        return drug.stock > drug.threshold;
                    case 'low-stock':
                        return drug.stock <= drug.threshold && drug.stock > 0;
                    case 'out-of-stock':
                        return drug.stock === 0;
                    case 'expiring-soon':
                        return expiryDate <= new Date(Date.now() + (30 * 24 * 60 * 60 * 1000));
                    default:
                        return true;
                }
            });
        }

        // Apply sorting
        switch (sortBy.value) {
            case 'name-asc':
                filtered.sort((a, b) => a.name.localeCompare(b.name));
                break;
            case 'name-desc':
                filtered.sort((a, b) => b.name.localeCompare(a.name));
                break;
            case 'stock-asc':
                filtered.sort((a, b) => a.stock - b.stock);
                break;
            case 'stock-desc':
                filtered.sort((a, b) => b.stock - a.stock);
                break;
            case 'expiry-asc':
                filtered.sort((a, b) => new Date(a.expiryDate) - new Date(b.expiryDate));
                break;
        }

        initInventoryTable(filtered);
    }

    // Add event listeners for filters
    searchInput?.addEventListener('input', applyFilters);
    categoryFilter?.addEventListener('change', applyFilters);
    statusFilter?.addEventListener('change', applyFilters);
    sortBy?.addEventListener('change', applyFilters);

    // Toast notification function
    function showToast(type, title, message) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                <div class="toast-message">
                    <span class="toast-title">${title}</span>
                    <span class="toast-text">${message}</span>
                </div>
            </div>
            <div class="toast-progress"></div>
        `;

        const toastContainer = document.getElementById('toast-container');
        toastContainer?.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('hide');
            setTimeout(() => toast.remove(), 500);
        }, 5000);
    }

    // Initialize data
    await fetchInventoryData();
});


// Initialize barcode scanner
async function initBarcodeScanner() {
    const scanner = document.getElementById('barcode-scanner');
    scanner.innerHTML = '';
    scanner.classList.add('active');
    
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
        });
        
        const videoElement = document.createElement('video');
        videoElement.srcObject = stream;
        videoElement.style.width = '100%';
        videoElement.style.maxWidth = '640px';
        scanner.appendChild(videoElement);
        await videoElement.play();

        // Add stop button
        const stopButton = document.createElement('button');
        stopButton.className = 'btn btn-danger stop-scan-btn';
        stopButton.innerHTML = '<i class="fas fa-stop"></i> Stop';
        scanner.appendChild(stopButton);

        stopButton.addEventListener('click', () => {
            stream.getTracks().forEach(track => track.stop());
            scanner.innerHTML = '';
            scanner.classList.remove('active');
        });

        // Simulate barcode detection (in real implementation, use proper barcode detection)
        setTimeout(() => {
            stream.getTracks().forEach(track => track.stop());
            scanner.innerHTML = '';
            scanner.classList.remove('active');
            
            // Mock successful scan
            const mockBarcode = generateRandomBarcode();
            fillFormWithMockData(mockBarcode);
        }, 3000);

    } catch (error) {
        console.error('Camera access error:', error);
        showToast('error', 'Error', 'Could not access camera');
        scanner.classList.remove('active');
    }
}

// Generate random barcode
function generateRandomBarcode() {
    return Math.floor(Math.random() * 10000000000000).toString().padStart(13, '0');
}

// Fill form with mock data
function fillFormWithMockData(barcode) {
    const mockData = {
        name: "Test Medicine",
        category: "antibiotics",
        stock: 100,
        unit: "tablets",
        price: 29.99,
        threshold: 20,
        supplier: "pharma-plus",
        description: "Test medicine description",
        expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]
    };

    document.getElementById('drug-name').value = mockData.name;
    document.getElementById('drug-category').value = mockData.category;
    document.getElementById('drug-stock').value = mockData.stock;
    document.getElementById('drug-unit').value = mockData.unit;
    document.getElementById('drug-price').value = mockData.price;
    document.getElementById('drug-threshold').value = mockData.threshold;
    document.getElementById('drug-supplier').value = mockData.supplier;
    document.getElementById('drug-description').value = mockData.description;
    document.getElementById('drug-expiry').value = mockData.expiryDate;
    
    showToast('success', 'Barcode Scanned', `Barcode ${barcode} scanned successfully`);
}

// Add event listeners
document.getElementById('start-barcode-scanner')?.addEventListener('click', initBarcodeScanner);
document.getElementById('test-barcode-scanner')?.addEventListener('click', () => fillFormWithMockData(generateRandomBarcode()));