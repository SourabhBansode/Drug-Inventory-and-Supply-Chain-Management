document.addEventListener('DOMContentLoaded', function() {
  // Set current date
  const currentDate = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  document.getElementById('current-date').textContent = currentDate.toLocaleDateString('en-US', options);
  
  // Sample order data
  const orderData = [
      {
          id: 'ORD-12345',
          date: '2023-05-15',
          supplier: 'pharma-plus',
          supplierContact: 'John Smith (555-123-4567)',
          items: [
              { drug: 'Paracetamol 500mg', quantity: 5000, unit: 'tablets', unitPrice: 0.15 },
              { drug: 'Amoxicillin 250mg', quantity: 2000, unit: 'capsules', unitPrice: 0.45 },
              { drug: 'Lisinopril 10mg', quantity: 1000, unit: 'tablets', unitPrice: 0.30 }
          ],
          total: 1375.00,
          status: 'shipped',
          expectedDelivery: '2023-05-22',
          notes: 'Please deliver to the back entrance of the pharmacy. Contact the pharmacy manager upon arrival.',
          timeline: [
              { status: 'created', date: '2023-05-15T09:30:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-05-16T11:15:00', description: 'Order confirmed and processing started' },
              { status: 'shipped', date: '2023-05-18T14:45:00', description: 'Order shipped via Express Delivery' }
          ]
      },
      {
          id: 'ORD-12346',
          date: '2023-05-10',
          supplier: 'med-supplies',
          supplierContact: 'Sarah Johnson (555-987-6543)',
          items: [
              { drug: 'Salbutamol Inhaler', quantity: 100, unit: 'inhalers', unitPrice: 8.50 },
              { drug: 'Metformin 500mg', quantity: 3000, unit: 'tablets', unitPrice: 0.20 }
          ],
          total: 1450.00,
          status: 'delivered',
          expectedDelivery: '2023-05-17',
          notes: '',
          timeline: [
              { status: 'created', date: '2023-05-10T10:15:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-05-11T09:30:00', description: 'Order confirmed and processing started' },
              { status: 'shipped', date: '2023-05-12T16:20:00', description: 'Order shipped via Standard Delivery' },
              { status: 'delivered', date: '2023-05-16T11:45:00', description: 'Order delivered and received by Jane Smith' }
          ]
      },
      {
          id: 'ORD-12347',
          date: '2023-05-18',
          supplier: 'global-pharma',
          supplierContact: 'Michael Brown (555-456-7890)',
          items: [
              { drug: 'Ibuprofen 400mg', quantity: 4000, unit: 'tablets', unitPrice: 0.18 },
              { drug: 'Ciprofloxacin 500mg', quantity: 1000, unit: 'tablets', unitPrice: 0.65 }
          ],
          total: 1370.00,
          status: 'pending',
          expectedDelivery: '2023-05-25',
          notes: 'Urgent order, please expedite.',
          timeline: [
              { status: 'created', date: '2023-05-18T14:20:00', description: 'Order created by John Doe' }
          ]
      },
      {
          id: 'ORD-12348',
          date: '2023-05-05',
          supplier: 'health-distributors',
          supplierContact: 'Emily Wilson (555-234-5678)',
          items: [
              { drug: 'Omeprazole 20mg', quantity: 2000, unit: 'capsules', unitPrice: 0.25 },
              { drug: 'Loratadine 10mg', quantity: 1500, unit: 'tablets', unitPrice: 0.22 }
          ],
          total: 830.00,
          status: 'delivered',
          expectedDelivery: '2023-05-12',
          notes: '',
          timeline: [
              { status: 'created', date: '2023-05-05T11:10:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-05-06T09:45:00', description: 'Order confirmed and processing started' },
              { status: 'shipped', date: '2023-05-08T15:30:00', description: 'Order shipped via Express Delivery' },
              { status: 'delivered', date: '2023-05-11T10:15:00', description: 'Order delivered and received by Mark Johnson' }
          ]
      },
      {
          id: 'ORD-12349',
          date: '2023-05-12',
          supplier: 'medical-solutions',
          supplierContact: 'David Clark (555-876-5432)',
          items: [
              { drug: 'Oseltamivir 75mg', quantity: 500, unit: 'capsules', unitPrice: 2.80 }
          ],
          total: 1400.00,
          status: 'processing',
          expectedDelivery: '2023-05-19',
          notes: 'Please include batch numbers and expiry dates for all items.',
          timeline: [
              { status: 'created', date: '2023-05-12T13:25:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-05-13T10:40:00', description: 'Order confirmed and processing started' }
          ]
      },
      {
          id: 'ORD-12350',
          date: '2023-04-28',
          supplier: 'pharma-plus',
          supplierContact: 'John Smith (555-123-4567)',
          items: [
              { drug: 'Paracetamol 500mg', quantity: 3000, unit: 'tablets', unitPrice: 0.15 },
              { drug: 'Metformin 500mg', quantity: 2000, unit: 'tablets', unitPrice: 0.20 }
          ],
          total: 850.00,
          status: 'delivered',
          expectedDelivery: '2023-05-05',
          notes: '',
          timeline: [
              { status: 'created', date: '2023-04-28T09:15:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-04-29T11:30:00', description: 'Order confirmed and processing started' },
              { status: 'shipped', date: '2023-05-01T14:20:00', description: 'Order shipped via Standard Delivery' },
              { status: 'delivered', date: '2023-05-04T09:45:00', description: 'Order delivered and received by Jane Smith' }
          ]
      },
      {
          id: 'ORD-12351',
          date: '2023-05-02',
          supplier: 'med-supplies',
          supplierContact: 'Sarah Johnson (555-987-6543)',
          items: [
              { drug: 'Amoxicillin 250mg', quantity: 1500, unit: 'capsules', unitPrice: 0.45 }
          ],
          total: 675.00,
          status: 'canceled',
          expectedDelivery: '2023-05-09',
          notes: '',
          timeline: [
              { status: 'created', date: '2023-05-02T10:30:00', description: 'Order created by John Doe' },
              { status: 'processing', date: '2023-05-03T09:15:00', description: 'Order confirmed and processing started' },
              { status: 'canceled', date: '2023-05-04T15:45:00', description: 'Order canceled due to stock unavailability' }
          ]
      }
  ];
  
  // Initialize the order table
  initOrderTable(orderData);
  
  // Initialize order alerts
  initOrderAlerts(orderData);
  
  // Create Order Button
  const createOrderBtn = document.getElementById('create-order-btn');
  const orderModal = document.getElementById('order-modal');
  const closeModal = document.getElementById('close-modal');
  const cancelOrder = document.getElementById('cancel-order');
  const saveOrder = document.getElementById('save-order');
  const orderForm = document.getElementById('order-form');
  
  createOrderBtn.addEventListener('click', function() {
      // Reset form
      orderForm.reset();
      document.getElementById('order-id').value = '';
      document.getElementById('modal-title').textContent = 'Create New Order';
      
      // Set default order date to today
      document.getElementById('order-date').valueAsDate = new Date();
      // Add test barcode button
    const actionButtons = document.querySelector('.modal-footer');
    const testBarcodeBtn = document.createElement('button');
    testBarcodeBtn.type = 'button';
    testBarcodeBtn.className = 'btn btn-outline';
    testBarcodeBtn.innerHTML = '<i class="fas fa-barcode"></i> Test Barcode';
    testBarcodeBtn.addEventListener('click', fillTestData);
    actionButtons.insertBefore(testBarcodeBtn, actionButtons.firstChild);

      // Reset order items
      const orderItems = document.getElementById('order-items');
      orderItems.innerHTML = `
          <div class="order-item">
              <div class="form-row">
                  <div class="form-group">
                      <label for="item-drug-1">Drug*</label>
                      <select id="item-drug-1" class="item-drug" required>
                          <option value="">Select Drug</option>
                          <option value="paracetamol">Paracetamol 500mg</option>
                          <option value="amoxicillin">Amoxicillin 250mg</option>
                          <option value="lisinopril">Lisinopril 10mg</option>
                          <option value="salbutamol">Salbutamol Inhaler</option>
                          <option value="metformin">Metformin 500mg</option>
                      </select>
                  </div>
                  <div class="form-group">
                      <label for="item-quantity-1">Quantity*</label>
                      <input type="number" id="item-quantity-1" class="item-quantity" min="1" required>
                  </div>
                  <div class="form-group">
                      <label for="item-unit-1">Unit*</label>
                      <select id="item-unit-1" class="item-unit" required>
                          <option value="">Select Unit</option>
                          <option value="tablets">Tablets</option>
                          <option value="capsules">Capsules</option>
                          <option value="bottles">Bottles</option>
                          <option value="vials">Vials</option>
                          <option value="ampules">Ampules</option>
                          <option value="syringes">Syringes</option>
                      </select>
                  </div>
                  <div class="form-group item-actions">
                      <button type="button" class="btn btn-icon btn-outline remove-item" title="Remove Item">
                          <i class="fas fa-trash-alt"></i>
                      </button>
                  </div>
              </div>
          </div>
      `;
      
      // Add event listener to remove item button
      addRemoveItemListeners();
      
      // Show modal
      orderModal.classList.add('active');
      function fillTestData() {
        // Fill supplier info
        document.getElementById('order-supplier').value = 'pharma-plus';
        
        // Fill order items with test data
        const orderItems = document.getElementById('order-items');
        orderItems.innerHTML = `
            <div class="order-item">
                <div class="form-row">
                    <div class="form-group">
                        <label for="item-drug-1">Drug*</label>
                        <select id="item-drug-1" class="item-drug" required>
                            <option value="paracetamol" selected>Paracetamol 500mg</option>
                            <option value="amoxicillin">Amoxicillin 250mg</option>
                            <option value="lisinopril">Lisinopril 10mg</option>
                            <option value="salbutamol">Salbutamol Inhaler</option>
                            <option value="metformin">Metformin 500mg</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="item-quantity-1">Quantity*</label>
                        <input type="number" id="item-quantity-1" class="item-quantity" value="1000" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="item-unit-1">Unit*</label>
                        <select id="item-unit-1" class="item-unit" required>
                            <option value="tablets" selected>Tablets</option>
                            <option value="capsules">Capsules</option>
                            <option value="bottles">Bottles</option>
                            <option value="vials">Vials</option>
                            <option value="ampules">Ampules</option>
                            <option value="syringes">Syringes</option>
                        </select>
                    </div>
                    <div class="form-group item-actions">
                        <button type="button" class="btn btn-icon btn-outline remove-item" title="Remove Item">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Add notes
        document.getElementById('order-notes').value = 'Test order generated from barcode scan';
        
        // Re-add event listeners
        addRemoveItemListeners();
        
        // Show success message
        showToast('success', 'Test Data', 'Form filled with test data');
    }
  });
  
  closeModal.addEventListener('click', function() {
      orderModal.classList.remove('active');
  });
  
  cancelOrder.addEventListener('click', function() {
      orderModal.classList.remove('active');
  });
  
  saveOrder.addEventListener('click', function() {
      // Validate form
      if (!orderForm.checkValidity()) {
          orderForm.reportValidity();
          return;
      }
      
      // Get form values
      const orderId = document.getElementById('order-id').value || `ORD-${Math.floor(10000 + Math.random() * 90000)}`;
      const orderDate = document.getElementById('order-date').value;
      const orderSupplier = document.getElementById('order-supplier').value;
      const orderNotes = document.getElementById('order-notes').value;
      
      // Get order items
      const orderItems = [];
      const itemElements = document.querySelectorAll('.order-item');
      
      itemElements.forEach((item, index) => {
          const drugSelect = item.querySelector('.item-drug');
          const quantityInput = item.querySelector('.item-quantity');
          const unitSelect = item.querySelector('.item-unit');
          
          const drugValue = drugSelect.value;
          const drugText = drugSelect.options[drugSelect.selectedIndex].text;
          const quantity = parseInt(quantityInput.value);
          const unit = unitSelect.value;
          
          // Mock unit price based on drug
          let unitPrice = 0;
          switch (drugValue) {
              case 'paracetamol':
                  unitPrice = 0.15;
                  break;
              case 'amoxicillin':
                  unitPrice = 0.45;
                  break;
              case 'lisinopril':
                  unitPrice = 0.30;
                  break;
              case 'salbutamol':
                  unitPrice = 8.50;
                  break;
              case 'metformin':
                  unitPrice = 0.20;
                  break;
              default:
                  unitPrice = 0.50;
          }
          
          orderItems.push({
              drug: drugText,
              quantity: quantity,
              unit: unit,
              unitPrice: unitPrice
          });
      });
      
      // Calculate total
      const total = orderItems.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
      
      // Create order object
      const order = {
          id: orderId,
          date: orderDate,
          supplier: orderSupplier,
          supplierContact: getSupplierContact(orderSupplier),
          items: orderItems,
          total: total,
          status: 'pending',
          expectedDelivery: calculateExpectedDelivery(orderDate),
          notes: orderNotes,
          timeline: [
              { 
                  status: 'created', 
                  date: new Date().toISOString(), 
                  description: 'Order created by John Doe' 
              }
          ]
      };
      
      // Add order to data
      orderData.unshift(order);
      
      // Refresh table
      initOrderTable(orderData);
      
      // Refresh alerts
      initOrderAlerts(orderData);
      
      // Show toast
      showToast('success', 'Order Created', `Order ${orderId} has been created successfully.`);
      
      // Close modal
      orderModal.classList.remove('active');
  });
  
  // Add Item Button
  const addItemBtn = document.getElementById('add-item-btn');
  
  addItemBtn.addEventListener('click', function() {
      const orderItems = document.getElementById('order-items');
      const itemCount = orderItems.querySelectorAll('.order-item').length + 1;
      
      const newItem = document.createElement('div');
      newItem.className = 'order-item';
      newItem.innerHTML = `
          <div class="form-row">
              <div class="form-group">
                  <label for="item-drug-${itemCount}">Drug*</label>
                  <select id="item-drug-${itemCount}" class="item-drug" required>
                      <option value="">Select Drug</option>
                      <option value="paracetamol">Paracetamol 500mg</option>
                      <option value="amoxicillin">Amoxicillin 250mg</option>
                      <option value="lisinopril">Lisinopril 10mg</option>
                      <option value="salbutamol">Salbutamol Inhaler</option>
                      <option value="metformin">Metformin 500mg</option>
                  </select>
              </div>
              <div class="form-group">
                  <label for="item-quantity-${itemCount}">Quantity*</label>
                  <input type="number" id="item-quantity-${itemCount}" class="item-quantity" min="1" required>
              </div>
              <div class="form-group">
                  <label for="item-unit-${itemCount}">Unit*</label>
                  <select id="item-unit-${itemCount}" class="item-unit" required>
                      <option value="">Select Unit</option>
                      <option value="tablets">Tablets</option>
                      <option value="capsules">Capsules</option>
                      <option value="bottles">Bottles</option>
                      <option value="vials">Vials</option>
                      <option value="ampules">Ampules</option>
                      <option value="syringes">Syringes</option>
                  </select>
              </div>
              <div class="form-group item-actions">
                  <button type="button" class="btn btn-icon btn-outline remove-item" title="Remove Item">
                      <i class="fas fa-trash-alt"></i>
                  </button>
              </div>
          </div>
      `;
      
      orderItems.appendChild(newItem);
      
      // Add event listener to remove item button
      addRemoveItemListeners();
  });
  
  // Function to add event listeners to remove item buttons
  function addRemoveItemListeners() {
      const removeButtons = document.querySelectorAll('.remove-item');
      
      removeButtons.forEach(button => {
          button.addEventListener('click', function() {
              const orderItems = document.getElementById('order-items');
              const itemCount = orderItems.querySelectorAll('.order-item').length;
              
              // Don't remove if it's the only item
              if (itemCount <= 1) {
                  showToast('warning', 'Cannot Remove', 'At least one item is required for an order.');
                  return;
              }
              
              const orderItem = this.closest('.order-item');
              orderItem.remove();
          });
      });
  }
  
  // Order Details Modal
  const orderDetailsModal = document.getElementById('order-details-modal');
  const closeDetailsModal = document.getElementById('close-details-modal');
  const updateStatusBtn = document.getElementById('update-status');
  const printOrderBtn = document.getElementById('print-order');
  let currentOrderId = null;
  
  closeDetailsModal.addEventListener('click', function() {
      orderDetailsModal.classList.remove('active');
  });
  
  updateStatusBtn.addEventListener('click', function() {
      // Open status update modal
      const statusModal = document.getElementById('status-modal');
      document.getElementById('status-order-id').value = currentOrderId;
      
      // Get current order status
      const order = orderData.find(order => order.id === currentOrderId);
      if (order) {
          const statusSelect = document.getElementById('status-select');
          statusSelect.value = '';
          
          // Remove options that don't make sense based on current status
          Array.from(statusSelect.options).forEach(option => {
              option.disabled = false;
          });
          
          if (order.status === 'delivered' || order.status === 'canceled') {
              // Can't change status if already delivered or canceled
              Array.from(statusSelect.options).forEach(option => {
                  if (option.value !== '') {
                      option.disabled = true;
                  }
              });
              showToast('warning', 'Status Update', `Cannot update status for ${order.status} orders.`);
              return;
          } else if (order.status === 'shipped') {
              // Can only mark as delivered or canceled if shipped
              Array.from(statusSelect.options).forEach(option => {
                  if (option.value !== 'delivered' && option.value !== 'canceled' && option.value !== '') {
                      option.disabled = true;
                  }
              });
          } else if (order.status === 'processing') {
              // Can't go back to pending if processing
              Array.from(statusSelect.options).forEach(option => {
                  if (option.value === 'pending') {
                      option.disabled = true;
                  }
              });
          }
      }
      
      statusModal.classList.add('active');
  });
  
  printOrderBtn.addEventListener('click', function() {
      showToast('info', 'Print Order', 'Printing functionality would be implemented here.');
  });
  
  // Status Update Modal
  const statusModal = document.getElementById('status-modal');
  const closeStatusModal = document.getElementById('close-status-modal');
  const cancelStatus = document.getElementById('cancel-status');
  const saveStatus = document.getElementById('save-status');
  const statusForm = document.getElementById('status-form');
  
  closeStatusModal.addEventListener('click', function() {
      statusModal.classList.remove('active');
  });
  
  cancelStatus.addEventListener('click', function() {
      statusModal.classList.remove('active');
  });
  
  saveStatus.addEventListener('click', function() {
      // Validate form
      if (!statusForm.checkValidity()) {
          statusForm.reportValidity();
          return;
      }
      
      const orderId = document.getElementById('status-order-id').value;
      const newStatus = document.getElementById('status-select').value;
      const statusNotes = document.getElementById('status-notes').value;
      
      // Update order status
      const orderIndex = orderData.findIndex(order => order.id === orderId);
      if (orderIndex !== -1) {
          const order = orderData[orderIndex];
          const oldStatus = order.status;
          order.status = newStatus;
          
          // Add to timeline
          order.timeline.push({
              status: newStatus,
              date: new Date().toISOString(),
              description: statusNotes || `Order marked as ${newStatus}`
          });
          
          // Refresh table
          initOrderTable(orderData);
          
          // Refresh alerts
          initOrderAlerts(orderData);
          
          // Update details modal if open
          updateOrderDetailsModal(order);
          
          // Show toast
          showToast('success', 'Status Updated', `Order ${orderId} status changed from ${oldStatus} to ${newStatus}.`);
      }
      
      // Close modal
      statusModal.classList.remove('active');
  });
  
  // Cancel Order Modal
  const cancelOrderModal = document.getElementById('cancel-order-modal');
  const closeCancelModal = document.getElementById('close-cancel-modal');
  const backCancel = document.getElementById('back-cancel');
  const confirmCancel = document.getElementById('confirm-cancel');
  
  closeCancelModal.addEventListener('click', function() {
      cancelOrderModal.classList.remove('active');
  });
  
  backCancel.addEventListener('click', function() {
      cancelOrderModal.classList.remove('active');
  });
  
  confirmCancel.addEventListener('click', function() {
      const orderId = document.getElementById('cancel-order-id').textContent;
      const cancelReason = document.getElementById('cancel-reason').value;
      
      if (!cancelReason.trim()) {
          document.getElementById('cancel-reason').focus();
          return;
      }
      
      // Update order status
      const orderIndex = orderData.findIndex(order => order.id === orderId);
      if (orderIndex !== -1) {
          const order = orderData[orderIndex];
          const oldStatus = order.status;
          order.status = 'canceled';
          
          // Add to timeline
          order.timeline.push({
              status: 'canceled',
              date: new Date().toISOString(),
              description: `Order canceled: ${cancelReason}`
          });
          
          // Refresh table
          initOrderTable(orderData);
          
          // Refresh alerts
          initOrderAlerts(orderData);
          
          // Show toast
          showToast('info', 'Order Canceled', `Order ${orderId} has been canceled.`);
      }
      
      // Close modal
      cancelOrderModal.classList.remove('active');
      
      // Close details modal if open
      orderDetailsModal.classList.remove('active');
  });
  
  // Search functionality
  const orderSearch = document.getElementById('order-search');
  orderSearch.addEventListener('input', function() {
      const searchTerm = this.value.toLowerCase().trim();
      
      if (searchTerm === '') {
          initOrderTable(orderData);
          return;
      }
      
      const filteredData = orderData.filter(order => 
          order.id.toLowerCase().includes(searchTerm) ||
          order.supplier.toLowerCase().includes(searchTerm) ||
          order.items.some(item => item.drug.toLowerCase().includes(searchTerm))
      );
      
      initOrderTable(filteredData);
  });
  
  // Status filter
  const statusFilter = document.getElementById('status-filter');
  statusFilter.addEventListener('change', function() {
      applyFilters();
  });
  
  // Supplier filter
  const supplierFilter = document.getElementById('supplier-filter');
  supplierFilter.addEventListener('change', function() {
      applyFilters();
  });
  
  // Date filter
  const dateFilter = document.getElementById('date-filter');
  dateFilter.addEventListener('change', function() {
      applyFilters();
  });
  
  // Apply all filters
  function applyFilters() {
      let filteredData = [...orderData];
      
      // Apply status filter
      const status = statusFilter.value;
      if (status !== 'all') {
          filteredData = filteredData.filter(order => order.status === status);
      }
      
      // Apply supplier filter
      const supplier = supplierFilter.value;
      if (supplier !== 'all') {
          filteredData = filteredData.filter(order => order.supplier === supplier);
      }
      
      // Apply date filter
      const dateRange = dateFilter.value;
      if (dateRange !== 'all') {
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          
          const startDate = new Date(today);
          
          switch (dateRange) {
              case 'today':
                  // startDate is already today
                  break;
              case 'week':
                  startDate.setDate(today.getDate() - today.getDay()); // Start of week (Sunday)
                  break;
              case 'month':
                  startDate.setDate(1); // Start of month
                  break;
              case 'quarter':
                  const quarter = Math.floor(today.getMonth() / 3);
                  startDate.setMonth(quarter * 3, 1); // Start of quarter
                  break;
              case 'year':
                  startDate.setMonth(0, 1); // Start of year
                  break;
              case 'custom':
                  // Custom date range would be implemented here
                  break;
          }
          
          filteredData = filteredData.filter(order => {
              const orderDate = new Date(order.date);
              return orderDate >= startDate && orderDate <= today;
          });
      }
      
      // Apply search filter
      const searchTerm = orderSearch.value.toLowerCase().trim();
      if (searchTerm !== '') {
          filteredData = filteredData.filter(order => 
              order.id.toLowerCase().includes(searchTerm) ||
              order.supplier.toLowerCase().includes(searchTerm) ||
              order.items.some(item => item.drug.toLowerCase().includes(searchTerm))
          );
      }
      
      // Update table
      initOrderTable(filteredData);
  }
  
  // Initialize order table
  function initOrderTable(data) {
      const tableBody = document.getElementById('order-table-body');
      tableBody.innerHTML = '';
      
      if (data.length === 0) {
          const emptyRow = document.createElement('tr');
          emptyRow.innerHTML = `
              <td colspan="8" style="text-align: center; padding: 2rem;">
                  <div style="color: var(--muted-foreground);">
                      <i class="fas fa-shopping-cart" style="font-size: 3rem; margin-bottom: 1rem; display: block;"></i>
                      <p>No orders found. Try adjusting your filters or create a new order.</p>
                  </div>
              </td>
          `;
          tableBody.appendChild(emptyRow);
          return;
      }
      
      // Update pagination info
      document.getElementById('total-items').textContent = data.length;
      
      // For simplicity, we're showing all items without pagination in this example
      document.getElementById('showing-start').textContent = '1';
      document.getElementById('showing-end').textContent = data.length;
      
      data.forEach(order => {
          const row = document.createElement('tr');
          
          // Format date
          const formattedDate = new Date(order.date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
          });
          
          // Format expected delivery date
          const formattedDelivery = new Date(order.expectedDelivery).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
          });
          
          // Format supplier name
          const supplierName = order.supplier.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
          
          // Format total
          const formattedTotal = `₹${order.total.toFixed(2)}`;
          
          // Get item count
          const itemCount = order.items.length;
          
          row.innerHTML = `
              <td>${order.id}</td>
              <td>${formattedDate}</td>
              <td>${supplierName}</td>
              <td>${itemCount} item${itemCount !== 1 ? 's' : ''}</td>
              <td>${formattedTotal}</td>
              <td><span class="status-badge status-${order.status}">${capitalizeFirstLetter(order.status)}</span></td>
              <td>${formattedDelivery}</td>
              <td>
                  <div class="action-buttons-cell">
                      <button class="action-btn view-btn" data-id="${order.id}" title="View Details">
                          <i class="fas fa-eye"></i>
                      </button>
                      ${order.status !== 'canceled' && order.status !== 'delivered' ? `
                          <button class="action-btn cancel-btn" data-id="${order.id}" title="Cancel Order">
                              <i class="fas fa-times"></i>
                          </button>
                      ` : ''}
                  </div>
              </td>
          `;
          
          tableBody.appendChild(row);
      });
      
      // Add event listeners to view and cancel buttons
      const viewButtons = document.querySelectorAll('.view-btn');
      viewButtons.forEach(button => {
          button.addEventListener('click', function() {
              const orderId = this.getAttribute('data-id');
              const order = data.find(item => item.id === orderId);
              
              if (order) {
                  // Store current order ID
                  currentOrderId = orderId;
                  
                  // Populate order details modal
                  updateOrderDetailsModal(order);
                  
                  // Show modal
                  orderDetailsModal.classList.add('active');
              }
          });
      });
      
      const cancelButtons = document.querySelectorAll('.cancel-btn');
      cancelButtons.forEach(button => {
          button.addEventListener('click', function() {
              const orderId = this.getAttribute('data-id');
              
              // Update cancel order modal
              document.getElementById('cancel-order-id').textContent = orderId;
              document.getElementById('cancel-reason').value = '';
              
              // Show cancel modal
              cancelOrderModal.classList.add('active');
          });
      });
  }
  
  // Update order details modal
  function updateOrderDetailsModal(order) {
      // Basic info
      document.getElementById('detail-order-id').textContent = order.id;
      
      const formattedDate = new Date(order.date).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
      });
      document.getElementById('detail-date').textContent = formattedDate;
      
      document.getElementById('detail-status').innerHTML = `
          <span class="status-badge status-${order.status}">${capitalizeFirstLetter(order.status)}</span>
      `;
      
      // Supplier info
      const supplierName = order.supplier.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
      document.getElementById('detail-supplier').textContent = supplierName;
      document.getElementById('detail-contact').textContent = order.supplierContact || 'Not available';
      
      const formattedDelivery = new Date(order.expectedDelivery).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
      });
      document.getElementById('detail-delivery').textContent = formattedDelivery;
      
      // Order items
      const itemsBody = document.getElementById('details-items-body');
      itemsBody.innerHTML = '';
      
      let subtotal = 0;
      
      order.items.forEach(item => {
          const row = document.createElement('tr');
          
          const itemTotal = item.quantity * item.unitPrice;
          subtotal += itemTotal;
          
          row.innerHTML = `
        <td>${item.drug}</td>
        <td>${item.quantity}</td>
        <td>${item.unit}</td>
        <td>₹${item.unitPrice.toFixed(2)}</td>
        <td>₹${itemTotal.toFixed(2)}</td>
        `;
          
          itemsBody.appendChild(row);
      });
      
      // Calculate totals
      const tax = subtotal * 0.1; // 10% tax
      const total = subtotal + tax;
      
      document.getElementById('detail-subtotal').textContent = `₹${subtotal.toFixed(2)}`;
      document.getElementById('detail-tax').textContent = `₹${tax.toFixed(2)}`;
      document.getElementById('detail-total').textContent = `₹${total.toFixed(2)}`;
      
      // Notes
      document.getElementById('detail-notes').textContent = order.notes || 'No notes provided.';
      
      // Timeline
      const timeline = document.getElementById('order-timeline');
      timeline.innerHTML = '';
      
      order.timeline.forEach(event => {
          const timelineItem = document.createElement('div');
          timelineItem.className = 'timeline-item';
          
          const eventDate = new Date(event.date);
          const formattedEventDate = eventDate.toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
              day: 'numeric'
          });
          
          const formattedEventTime = eventDate.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit'
          });
          
          timelineItem.innerHTML = `
              <div class="timeline-icon"></div>
              <div class="timeline-content">
                  <div class="timeline-title">${capitalizeFirstLetter(event.status)}</div>
                  <div class="timeline-date">${formattedEventDate} at ${formattedEventTime}</div>
                  <div class="timeline-description">${event.description}</div>
              </div>
          `;
          
          timeline.appendChild(timelineItem);
      });
      
      // Update status button
      if (order.status === 'delivered' || order.status === 'canceled') {
          updateStatusBtn.disabled = true;
          updateStatusBtn.style.opacity = '0.5';
          updateStatusBtn.style.cursor = 'not-allowed';
      } else {
          updateStatusBtn.disabled = false;
          updateStatusBtn.style.opacity = '1';
          updateStatusBtn.style.cursor = 'pointer';
      }
  }
  
  // Initialize order alerts
  function initOrderAlerts(data) {
      const alertsContainer = document.getElementById('order-alerts');
      alertsContainer.innerHTML = '';
      
      // Check for delayed orders
      const delayedOrders = data.filter(order => {
          if (order.status !== 'delivered' && order.status !== 'canceled') {
              const expectedDelivery = new Date(order.expectedDelivery);
              const today = new Date();
              return expectedDelivery < today;
          }
          return false;
      });
      
      // Check for pending orders
      const pendingOrders = data.filter(order => order.status === 'pending');
      
      // Create alerts
      if (delayedOrders.length > 0) {
          const delayedAlert = document.createElement('div');
          delayedAlert.className = 'alert danger';
          
          delayedAlert.innerHTML = `
              <div class="alert-icon">
                  <i class="fas fa-exclamation-circle"></i>
              </div>
              <div class="alert-content">
                  <div class="alert-title">Delayed Orders</div>
                  <div class="alert-message">
                      ${delayedOrders.length} order${delayedOrders.length !== 1 ? 's' : ''} ${delayedOrders.length !== 1 ? 'are' : 'is'} past the expected delivery date.
                  </div>
              </div>
              <div class="alert-actions">
                  <button class="btn btn-sm btn-outline view-delayed-btn">View Orders</button>
              </div>
          `;
          
          alertsContainer.appendChild(delayedAlert);
          
          // Add event listener to view delayed orders button
          const viewDelayedBtn = delayedAlert.querySelector('.view-delayed-btn');
          viewDelayedBtn.addEventListener('click', function() {
              // Filter to show only delayed orders
              statusFilter.value = 'all'; // Reset status filter
              supplierFilter.value = 'all'; // Reset supplier filter
              dateFilter.value = 'all'; // Reset date filter
              orderSearch.value = ''; // Reset search
              
              // Custom filter for delayed orders
              const filteredData = data.filter(order => {
                  if (order.status !== 'delivered' && order.status !== 'canceled') {
                      const expectedDelivery = new Date(order.expectedDelivery);
                      const today = new Date();
                      return expectedDelivery < today;
                  }
                  return false;
              });
              
              initOrderTable(filteredData);
          });
      }
      
      if (pendingOrders.length > 0) {
          const pendingAlert = document.createElement('div');
          pendingAlert.className = 'alert warning';
          
          pendingAlert.innerHTML = `
              <div class="alert-icon">
                  <i class="fas fa-clock"></i>
              </div>
              <div class="alert-content">
                  <div class="alert-title">Pending Orders</div>
                  <div class="alert-message">
                      ${pendingOrders.length} order${pendingOrders.length !== 1 ? 's' : ''} ${pendingOrders.length !== 1 ? 'are' : 'is'} pending and need to be processed.
                  </div>
              </div>
              <div class="alert-actions">
                  <button class="btn btn-sm btn-outline view-pending-btn">View Orders</button>
              </div>
          `;
          
          alertsContainer.appendChild(pendingAlert);
          
          // Add event listener to view pending orders button
          const viewPendingBtn = pendingAlert.querySelector('.view-pending-btn');
          viewPendingBtn.addEventListener('click', function() {
              // Filter to show only pending orders
              statusFilter.value = 'pending';
              supplierFilter.value = 'all'; // Reset supplier filter
              dateFilter.value = 'all'; // Reset date filter
              orderSearch.value = ''; // Reset search
              
              applyFilters();
          });
      }
      
      // If no alerts, hide the section
      if (delayedOrders.length === 0 && pendingOrders.length === 0) {
          alertsContainer.style.display = 'none';
      } else {
          alertsContainer.style.display = 'block';
      }
  }
  
  // Helper function to get supplier contact
  function getSupplierContact(supplier) {
      switch (supplier) {
          case 'pharma-plus':
              return 'John Smith (555-123-4567)';
          case 'med-supplies':
              return 'Sarah Johnson (555-987-6543)';
          case 'global-pharma':
              return 'Michael Brown (555-456-7890)';
          case 'health-distributors':
              return 'Emily Wilson (555-234-5678)';
          case 'medical-solutions':
              return 'David Clark (555-876-5432)';
          default:
              return 'Contact information not available';
      }
  }
  
  // Helper function to calculate expected delivery date (7 days from order date)
  function calculateExpectedDelivery(orderDate) {
      const date = new Date(orderDate);
      date.setDate(date.getDate() + 7);
      return date.toISOString().split('T')[0];
  }
  
  // Helper function to capitalize first letter
  function capitalizeFirstLetter(string) {
      return string.charAt(0).toUpperCase() + string.slice(1);
  }
  
  // Toast notification function
  function showToast(type, title, message) {
      const toastContainer = document.getElementById('toast-container');
      
      // Create toast element
      const toast = document.createElement('div');
      toast.className = `toast ${type}`;
      
      // Set icon based on type
      let icon = '';
      switch (type) {
          case 'success':
              icon = 'fa-check-circle';
              break;
          case 'error':
              icon = 'fa-exclamation-circle';
              break;
          case 'warning':
              icon = 'fa-exclamation-triangle';
              break;
          case 'info':
              icon = 'fa-info-circle';
              break;
      }
      
      toast.innerHTML = `
          <div class="toast-icon">
              <i class="fas ${icon}"></i>
          </div>
          <div class="toast-content">
              <div class="toast-title">${title}</div>
              <div class="toast-message">${message}</div>
          </div>
          <button class="toast-close">
              <i class="fas fa-times"></i>
          </button>
      `;
      
      // Add to container
      toastContainer.appendChild(toast);
      
      // Add close event
      const closeBtn = toast.querySelector('.toast-close');
      closeBtn.addEventListener('click', function() {
          toast.style.animation = 'slideOut 0.3s ease forwards';
          setTimeout(() => {
              toast.remove();
          }, 300);
      });
      
      // Auto remove after 5 seconds
      setTimeout(() => {
          if (toast.parentNode) {
              toast.style.animation = 'slideOut 0.3s ease forwards';
              setTimeout(() => {
                  if (toast.parentNode) {
                      toast.remove();
                  }
              }, 300);
          }
      }, 5000);
  }
  
  // Sidebar toggle (reusing from dashboard)
  const sidebarToggle = document.getElementById('sidebar-toggle');
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.querySelector('.main-content');
  
  sidebarToggle.addEventListener('click', function() {
      sidebar.classList.toggle('collapsed');
      
      if (sidebar.classList.contains('collapsed')) {
          mainContent.style.marginLeft = 'var(--sidebar-collapsed-width)';
      } else {
          mainContent.style.marginLeft = '0';
      }
  });
  
  // Profile dropdown toggle (reusing from dashboard)
  const profileDropdownToggle = document.querySelector('.profile-dropdown-toggle');
  const profileDropdown = document.querySelector('.profile-dropdown');
  
  profileDropdownToggle.addEventListener('click', function() {
      profileDropdown.classList.toggle('active');
  });
  
  // Close profile dropdown when clicking outside
  document.addEventListener('click', function(event) {
      if (!event.target.closest('.user-profile') && profileDropdown.classList.contains('active')) {
          profileDropdown.classList.remove('active');
      }
  });
  
  // Mobile sidebar toggle
  const mobileToggle = document.createElement('button');
  mobileToggle.className = 'mobile-sidebar-toggle';
  mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
  document.querySelector('.header-left').prepend(mobileToggle);
  
  mobileToggle.addEventListener('click', function() {
      sidebar.classList.toggle('active');
  });
  
  // Add mobile sidebar toggle styles
  const style = document.createElement('style');
  style.textContent = `
      .mobile-sidebar-toggle {
          display: none;
          background: none;
          border: none;
          font-size: 1.5rem;
          margin-right: 1rem;
          cursor: pointer;
          color: var(--foreground);
      }
      
      @media (max-width: 992px) {
          .mobile-sidebar-toggle {
              display: block;
          }
      }
  `;
  document.head.appendChild(style);
});
