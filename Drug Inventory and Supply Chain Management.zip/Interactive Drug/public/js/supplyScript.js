document.addEventListener("DOMContentLoaded", () => {
    const supplierCardsContainer = document.getElementById("supplier-cards")
    const supplierTableBody = document.getElementById("supplier-table-body")
    const supplierModal = document.getElementById("supplier-modal")
    const deleteModal = document.getElementById("delete-modal")
    const toastContainer = document.getElementById("toast-container")
  
    const addSupplierBtn = document.getElementById("add-supplier-btn")
    const closeModal = document.getElementById("close-modal")
    const cancelSupplier = document.getElementById("cancel-supplier")
    const saveSupplier = document.getElementById("save-supplier")
  
    const supplierForm = document.getElementById("supplier-form")
  
    const suppliers = JSON.parse(localStorage.getItem("suppliers")) || []
  
    // Initialize Page
    initPage()
  
    function initPage() {
      renderSuppliers()
      setupEventListeners()
    }
  
    // Render Suppliers in Cards and Table
    function renderSuppliers() {
      supplierCardsContainer.innerHTML = ""
      supplierTableBody.innerHTML = ""
  
      if (suppliers.length === 0) {
        supplierCardsContainer.innerHTML = `<p>No suppliers found.</p>`
        supplierTableBody.innerHTML = `<tr><td colspan="8">No suppliers found.</td></tr>`
        return
      }
  
      suppliers.forEach((supplier, index) => {
        // Render Card with enhanced styling
        const card = document.createElement("div")
        card.className = "supplier-card"
  
        // Get first letter of supplier name for logo
        const firstLetter = supplier.name.charAt(0).toUpperCase()
  
        // Generate random but consistent color for supplier logo
        const colorIndex = supplier.name.charCodeAt(0) % 5
        const colorClasses = ["primary", "success", "warning", "info", "danger"]
        const colorClass = colorClasses[colorIndex]
  
        card.innerHTML = `
                  <div class="card-header">
                      <div class="supplier-logo ${colorClass}-bg">
                          ${firstLetter}
                      </div>
                      <div class="supplier-info">
                          <h3>${supplier.name}</h3>
                          <div class="supplier-category">${supplier.category}</div>
                          <div class="supplier-rating">
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="fas fa-star"></i>
                              <i class="far fa-star"></i>
                              <span>${supplier.rating ? supplier.rating.toFixed(1) : "4.0"} / 5</span>
                          </div>
                      </div>
                  </div>
                  <div class="card-body">
                      <div class="contact-info">
                          <div class="contact-item">
                              <i class="fas fa-user"></i>
                              ${supplier.contactName}
                          </div>
                          <div class="contact-item">
                              <i class="fas fa-envelope"></i>
                              <a href="mailto:${supplier.email}">${supplier.email}</a>
                          </div>
                          <div class="contact-item">
                              <i class="fas fa-phone"></i>
                              <a href="tel:${supplier.phone}">${supplier.phone}</a>
                          </div>
                          ${
                            supplier.city && supplier.state
                              ? `
                          <div class="contact-item">
                              <i class="fas fa-map-marker-alt"></i>
                              ${supplier.city}, ${supplier.state}
                          </div>
                          `
                              : ""
                          }
                      </div>
                      
                      ${
                        supplier.products
                          ? `
                      <div class="supplier-products">
                          <h4>Products</h4>
                          <div class="product-tags">
                              ${supplier.products
                                .split(",")
                                .map((product) => `<span class="product-tag">${product.trim()}</span>`)
                                .join("")}
                          </div>
                      </div>
                      `
                          : ""
                      }
                  </div>
                  <div class="card-footer">
                      <span class="status-badge status-${supplier.status || "active"}">${supplier.status || "Active"}</span>
                      <div class="card-actions">
                          <button class="action-btn view-btn" title="View Details">
                              <i class="fas fa-eye"></i>
                          </button>
                          <button class="action-btn edit-btn" onclick="editSupplier(${index})" title="Edit Supplier">
                              <i class="fas fa-edit"></i>
                          </button>
                          <button class="action-btn delete-btn" onclick="confirmDelete(${index})" title="Delete Supplier">
                              <i class="fas fa-trash-alt"></i>
                          </button>
                          <button class="action-btn order-btn">
                              <i class="fas fa-shopping-cart"></i> Order
                          </button>
                      </div>
                  </div>
              `
        supplierCardsContainer.appendChild(card)
  
        // Render Table Row
        const row = document.createElement("tr")
        row.innerHTML = `
                  <td>${supplier.name}</td>
                  <td>${supplier.category}</td>
                  <td>${supplier.contactName}</td>
                  <td>${supplier.city || ""}, ${supplier.state || ""}</td>
                  <td>${supplier.products || ""}</td>
                  <td>${supplier.rating ? supplier.rating.toFixed(1) : "4.0"} / 5</td>
                  <td><span class="status-badge status-${supplier.status || "active"}">${supplier.status || "Active"}</span></td>
                  <td>
                      <div class="action-buttons-cell">
                          <button class="action-btn view-btn" title="View Details">
                              <i class="fas fa-eye"></i>
                          </button>
                          <button class="action-btn edit-btn" onclick="editSupplier(${index})" title="Edit Supplier">
                              <i class="fas fa-edit"></i>
                          </button>
                          <button class="action-btn delete-btn" onclick="confirmDelete(${index})" title="Delete Supplier">
                              <i class="fas fa-trash-alt"></i>
                          </button>
                      </div>
                  </td>
              `
        supplierTableBody.appendChild(row)
      })
  
      // Add event listeners to action buttons
      document.querySelectorAll(".view-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          // View functionality would go here
          showToast("info", "View Supplier", "Viewing supplier details")
        })
      })
  
      document.querySelectorAll(".edit-btn").forEach((btn) => {
        if (!btn.hasAttribute("onclick")) {
          btn.addEventListener("click", function () {
            const index = this.closest("tr")?.rowIndex - 1
            if (index !== undefined && index >= 0) {
              editSupplier(index)
            }
          })
        }
      })
  
      document.querySelectorAll(".delete-btn").forEach((btn) => {
        if (!btn.hasAttribute("onclick")) {
          btn.addEventListener("click", function () {
            const index = this.closest("tr")?.rowIndex - 1
            if (index !== undefined && index >= 0) {
              confirmDelete(index)
            }
          })
        }
      })
    }
  
    // Event Listeners Setup
    // Inside setupEventListeners function
    function setupEventListeners() {
        addSupplierBtn.addEventListener("click", () => {
            supplierForm.reset();
            document.getElementById("supplier-id").value = "";
    
            // Add test data button
            const actionButtons = document.querySelector('#supplier-modal .modal-footer');
            const testDataBtn = document.createElement('button');
            testDataBtn.type = 'button';
            testDataBtn.className = 'btn btn-outline';
            testDataBtn.innerHTML = '<i class="fas fa-vial"></i> Test Data';
            testDataBtn.addEventListener('click', fillTestData);
            actionButtons.insertBefore(testDataBtn, actionButtons.firstChild);
    
            supplierModal.classList.add("active");
        });
  
        closeModal.addEventListener("click", () => {
            supplierModal.classList.remove("active")
        })
  
        cancelSupplier.addEventListener("click", () => {
            supplierModal.classList.remove("active")
        })
  
        saveSupplier.addEventListener("click", () => {
            if (!supplierForm.checkValidity()) {
                supplierForm.reportValidity()
                return
            }
  
            const supplier = {
                id: Date.now(),
                name: document.getElementById("supplier-name").value,
                category: document.getElementById("supplier-category").value,
                contactName: document.getElementById("supplier-contact-name").value,
                email: document.getElementById("supplier-email").value,
                phone: document.getElementById("supplier-phone").value,
                website: document.getElementById("supplier-website").value,
                address: document.getElementById("supplier-address").value,
                city: document.getElementById("supplier-city").value,
                state: document.getElementById("supplier-state").value,
                country: document.getElementById("supplier-country").value,
                zip: document.getElementById("supplier-zip").value,
                products: document.getElementById("supplier-products").value,
                notes: document.getElementById("supplier-notes").value,
                rating: 4.0,
                status: "active",
            }
  
            const supplierId = document.getElementById("supplier-id").value
            if (supplierId) {
                suppliers[Number.parseInt(supplierId)] = supplier
                showToast("success", "Supplier Updated", `${supplier.name} has been updated successfully.`)
            } else {
                suppliers.push(supplier)
                showToast("success", "Supplier Added", `${supplier.name} has been added successfully.`)
            }
  
            localStorage.setItem("suppliers", JSON.stringify(suppliers))
            supplierModal.classList.remove("active")
            renderSuppliers()
        })
    }
  
    // Add fillTestData function after setupEventListeners
    function fillTestData() {
        document.getElementById("supplier-name").value = "MediCare Plus";
        document.getElementById("supplier-category").value = "manufacturer";
        document.getElementById("supplier-contact-name").value = "Dr. Sarah Johnson";
        document.getElementById("supplier-email").value = "sarah.j@medicare-plus.com";
        document.getElementById("supplier-phone").value = "555-0123-4567";
        
        document.getElementById("supplier-address").value = "123 Healthcare Avenue, Medical District";
        document.getElementById("supplier-city").value = "Mumbai";
        document.getElementById("supplier-state").value = "Maharashtra";
        document.getElementById("supplier-country").value = "India";
        document.getElementById("supplier-zip").value = "400001";
        document.getElementById("supplier-products").value = "Antibiotics, Pain Relievers, Cardiac Medications";
        document.getElementById("supplier-notes").value = "Leading manufacturer of generic medications with ISO 9001 certification";
  
        showToast("success", "Test Data", "Form filled with test data");
    }
  
    // Edit Supplier
    window.editSupplier = (index) => {
      const supplier = suppliers[index]
  
      document.getElementById("supplier-id").value = index
      document.getElementById("supplier-name").value = supplier.name
      document.getElementById("supplier-category").value = supplier.category
      document.getElementById("supplier-contact-name").value = supplier.contactName
      document.getElementById("supplier-email").value = supplier.email
      document.getElementById("supplier-phone").value = supplier.phone
      document.getElementById("supplier-website").value = supplier.website || ""
      document.getElementById("supplier-address").value = supplier.address || ""
      document.getElementById("supplier-city").value = supplier.city || ""
      document.getElementById("supplier-state").value = supplier.state || ""
      document.getElementById("supplier-country").value = supplier.country || ""
      document.getElementById("supplier-zip").value = supplier.zip || ""
      document.getElementById("supplier-products").value = supplier.products || ""
      document.getElementById("supplier-notes").value = supplier.notes || ""
  
      supplierModal.classList.add("active")
    }
  
    // Confirm Delete
    window.confirmDelete = (index) => {
      const supplier = suppliers[index]
      document.getElementById("delete-supplier-name").textContent = supplier.name
      deleteModal.classList.add("active")
  
      const confirmBtn = document.getElementById("confirm-delete")
      confirmBtn.onclick = () => {
        suppliers.splice(index, 1)
        localStorage.setItem("suppliers", JSON.stringify(suppliers))
        renderSuppliers()
        deleteModal.classList.remove("active")
        showToast("info", "Supplier Deleted", `${supplier.name} has been deleted successfully.`)
      }
  
      const cancelBtn = document.getElementById("cancel-delete")
      cancelBtn.onclick = () => {
        deleteModal.classList.remove("active")
      }
    }
  
    // Display Toast Notification
    function showToast(type, title, message) {
      const toast = document.createElement("div")
      toast.className = `toast ${type}`
  
      // Set icon based on type
      let icon = ""
      switch (type) {
        case "success":
          icon = "fa-check-circle"
          break
        case "error":
          icon = "fa-exclamation-circle"
          break
        case "warning":
          icon = "fa-exclamation-triangle"
          break
        case "info":
          icon = "fa-info-circle"
          break
      }
  
      toast.innerHTML = `
              <div class="toast-icon">
                  <i class="fas ${icon}"></i>
              </div>
              <div class="toast-content">
                  <div class="toast-title">${title}</div>
                  <div class="toast-message">${message}</div>
              </div>
              <button class="toast-close">
                  <i class="fas fa-times"></i>
              </button>
          `
  
      toastContainer.appendChild(toast)
  
      // Add close event
      const closeBtn = toast.querySelector(".toast-close")
      closeBtn.addEventListener("click", () => {
        toast.style.animation = "slideOut 0.3s ease forwards"
        setTimeout(() => {
          toast.remove()
        }, 300)
      })
  
      // Auto remove after 5 seconds
      setTimeout(() => {
        if (toast.parentNode) {
          toast.style.animation = "slideOut 0.3s ease forwards"
          setTimeout(() => {
            if (toast.parentNode) {
              toast.remove()
            }
          }, 300)
        }
      }, 5000)
    }
  })