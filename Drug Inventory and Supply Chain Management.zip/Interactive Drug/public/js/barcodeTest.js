export function createTestUI() {
    const testUI = document.createElement('div');
    testUI.className = 'test-controls';
    testUI.innerHTML = `
        <div class="test-mode-banner">🔍 Test Mode Active</div>
        <div class="test-buttons">
            <button id="test-ean13">Test EAN-13</button>
            <button id="test-code128">Test Code-128</button>
            <button id="test-invalid">Test Invalid Barcode</button>
        </div>
        <div class="test-status"></div>
    `;
    return testUI;
}

export async function testBarcodeScanner() {
    
}

export const mockMedicineData = {
    'TEST123': {
        name: "Test Antibiotic",
        stock: 100,
        price: 29.99,
        expiryDate: new Date(Date.now() + (365 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0],
        barcode: "TEST123",
        category: "Antibiotics",
        unit: "tablets",
        supplier: "Test Pharma",
        threshold: 20,
        description: "Test antibiotic medicine"
    }
};

export function simulateBarcodeScan(barcode) {
    return mockMedicineData[barcode] || null;
}