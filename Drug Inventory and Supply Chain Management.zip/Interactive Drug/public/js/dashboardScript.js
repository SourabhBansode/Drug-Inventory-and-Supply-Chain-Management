document.addEventListener('DOMContentLoaded', async function() {
    // Set current date
    const currentDate = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('current-date').textContent = currentDate.toLocaleDateString('en-US', options);
    
    // Get user data from window.userData (passed from server)
    let userData = {
        firstName: 'Guest',
        lastName: 'User',
        role: 'Guest'
    };

    try {
        if (typeof window !== 'undefined' && window.userData) {
            userData = JSON.parse(window.userData);
        }
    } catch (error) {
        console.error('Error parsing user data:', error);
    }

    // Update user profile information
    const userNameElement = document.querySelector('.user-name');
    const userRoleElement = document.querySelector('.user-role');
    if (userNameElement) userNameElement.textContent = `${userData.firstName} ${userData.lastName}`;
    if (userRoleElement) userRoleElement.textContent = userData.role;
    
    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    
    sidebarToggle?.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
    });
    
    // Profile dropdown toggle
    const profileDropdownToggle = document.querySelector('.profile-dropdown-toggle');
    const profileDropdown = document.querySelector('.profile-dropdown');
    
    profileDropdownToggle?.addEventListener('click', function() {
        profileDropdown.classList.toggle('active');
    });
    
    // Close profile dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.user-profile') && profileDropdown?.classList.contains('active')) {
            profileDropdown.classList.remove('active');
        }
    });
    
    // Mobile sidebar toggle
    const mobileToggle = document.createElement('button');
    mobileToggle.className = 'mobile-sidebar-toggle';
    mobileToggle.innerHTML = '<i class="fas fa-bars"></i>';
    document.querySelector('.header-left')?.prepend(mobileToggle);
    
    mobileToggle.addEventListener('click', function() {
        sidebar.classList.toggle('active');
    });
    
    // Close sidebar when clicking on a link on mobile
    const sidebarLinks = document.querySelectorAll('.sidebar-nav a');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 992) {
                sidebar.classList.remove('active');
            }
        });
    });
    
    // Add mobile sidebar toggle styles
    const style = document.createElement('style');
    style.textContent = `
        .mobile-sidebar-toggle {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            margin-right: 1rem;
            cursor: pointer;
            color: var(--foreground);
        }
        
        @media (max-width: 992px) {
            .mobile-sidebar-toggle {
                display: block;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Service card hover effects
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = 'var(--shadow-lg)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'var(--shadow)';
        });
    });

    // Fetch dashboard data with error handling
    async function fetchDashboardData() {
        try {
            const [medicinesResponse, ordersResponse] = await Promise.all([
                fetch('/api/medicines').catch(() => ({ ok: false })),
                fetch('/api/orders').catch(() => ({ ok: false }))
            ]);

            const medicines = medicinesResponse.ok ? await medicinesResponse.json() : [];
            const orders = ordersResponse.ok ? await ordersResponse.json() : [];

            // Update overview cards if they exist
            const totalInventoryEl = document.getElementById('total-inventory');
            const pendingOrdersEl = document.getElementById('pending-orders');
            const lowStockEl = document.getElementById('low-stock');
            const totalSalesEl = document.getElementById('total-sales');
            const activeSuppliersEl = document.getElementById('active-suppliers');
            const monthlyRevenueEl = document.getElementById('monthly-revenue');

            if (totalInventoryEl) totalInventoryEl.textContent = medicines.length || '0';
            if (pendingOrdersEl) pendingOrdersEl.textContent = orders.filter(order => order.status === 'pending').length || '0';
            if (lowStockEl) {
                const lowStockCount = medicines.filter(med => med.stock <= med.threshold).length;
                lowStockEl.textContent = lowStockCount || '0';
            }
            if (totalSalesEl) {
                const completedOrders = orders.filter(order => order.status === 'completed');
                const totalSales = completedOrders.reduce((sum, order) => sum + (order.total || 0), 0);
                totalSalesEl.textContent = `$${totalSales.toFixed(2)}`;
            }
            if (activeSuppliersEl) activeSuppliersEl.textContent = '0'; // Placeholder for supplier count
            if (monthlyRevenueEl) {
                const currentMonth = new Date().getMonth();
                const monthlyOrders = orders.filter(order => {
                    const orderDate = new Date(order.createdAt);
                    return orderDate.getMonth() === currentMonth && order.status === 'completed';
                });
                const monthlyRevenue = monthlyOrders.reduce((sum, order) => sum + (order.total || 0), 0);
                monthlyRevenueEl.textContent = `₹${monthlyRevenue.toFixed(2)}`;
            }

            return { medicines, orders };
        } catch (error) {
            console.error('Error fetching dashboard data:', error);
            return { medicines: [], orders: [] };
        }
    }

    // Initialize charts with error handling
    async function initCharts() {
        try {
            const data = await fetchDashboardData();
            
            // Calculate inventory statistics
            const medicineStatuses = {
                inStock: 0,
                lowStock: 0,
                outOfStock: 0
            };

            data.medicines.forEach(medicine => {
                if (medicine.stock === 0) {
                    medicineStatuses.outOfStock++;
                } else if (medicine.stock <= medicine.threshold) {
                    medicineStatuses.lowStock++;
                } else {
                    medicineStatuses.inStock++;
                }
            });

            // Initialize Inventory Chart
            const inventoryCtx = document.getElementById('inventoryChart')?.getContext('2d');
            if (inventoryCtx) {
                new Chart(inventoryCtx, {
                    type: 'doughnut',
                    data: {
                        labels: ['In Stock', 'Low Stock', 'Out of Stock'],
                        datasets: [{
                            data: [
                                medicineStatuses.inStock,
                                medicineStatuses.lowStock,
                                medicineStatuses.outOfStock
                            ],
                            backgroundColor: ['#43a047', '#ff9800', '#e53935'],
                            borderWidth: 0
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        cutout: '70%',
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    pointStyle: 'circle'
                                }
                            }
                        }
                    }
                });
            }

            // Calculate monthly orders
            const monthlyOrders = new Array(6).fill(0);
            const currentYear = new Date().getFullYear();
            
            data.orders.forEach(order => {
                const orderDate = new Date(order.createdAt);
                if (orderDate.getFullYear() === currentYear && orderDate.getMonth() < 6) {
                    monthlyOrders[orderDate.getMonth()]++;
                }
            });

            // Initialize Orders Chart
            const ordersCtx = document.getElementById('ordersChart')?.getContext('2d');
            if (ordersCtx) {
                new Chart(ordersCtx, {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                        datasets: [{
                            label: 'Orders',
                            data: monthlyOrders,
                            borderColor: '#0066cc',
                            backgroundColor: 'rgba(0, 102, 204, 0.1)',
                            tension: 0.4,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { drawBorder: false }
                            },
                            x: {
                                grid: { display: false }
                            }
                        },
                        plugins: {
                            legend: { display: false }
                        }
                    }
                });
            }
        } catch (error) {
            console.error('Error initializing charts:', error);
            const chartContainers = document.querySelectorAll('.chart-container');
            chartContainers.forEach(container => {
                container.innerHTML = '<div class="chart-error">Failed to load chart data</div>';
            });
        }
    }

    // Initialize charts
    await initCharts();

    // Add notification functionality
    const notificationButton = document.querySelector('.notifications .icon-button');
    let notificationDropdown = null;
    
    notificationButton?.addEventListener('click', function() {
        if (notificationDropdown) {
            notificationDropdown.remove();
            notificationDropdown = null;
            return;
        }
        
        notificationDropdown = document.createElement('div');
        notificationDropdown.className = 'notification-dropdown';
        
        const notificationContent = `
            <div class="dropdown-header">
                <h3>Notifications</h3>
                <button class="mark-all-read">Mark all as read</button>
            </div>
            <div class="notification-list">
                <div class="notification-item unread">
                    <div class="notification-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <div class="notification-content">
                        <p>Low stock alert: Amoxicillin 250mg</p>
                        <span class="notification-time">2 hours ago</span>
                    </div>
                </div>
                <div class="notification-item unread">
                    <div class="notification-icon">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="notification-content">
                        <p>Shipment #12345 has been delayed</p>
                        <span class="notification-time">4 hours ago</span>
                    </div>
                </div>
                <div class="notification-item unread">
                    <div class="notification-icon">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div class="notification-content">
                        <p>New order #54321 received from City Hospital</p>
                        <span class="notification-time">Yesterday</span>
                    </div>
                </div>
            </div>
            <div class="dropdown-footer">
                <a href="#all-notifications">View all notifications</a>
            </div>
        `;
        
        notificationDropdown.innerHTML = notificationContent;
        document.querySelector('.notifications')?.appendChild(notificationDropdown);
        
        // Add notification dropdown styles
        const notificationStyle = document.createElement('style');
        notificationStyle.textContent = `
            .notification-dropdown {
                position: absolute;
                top: calc(100% + 0.5rem);
                right: 0;
                background-color: var(--background);
                border: 1px solid var(--border);
                border-radius: var(--radius);
                width: 300px;
                box-shadow: var(--shadow-lg);
                z-index: 100;
            }
            
            .dropdown-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 1rem;
                border-bottom: 1px solid var(--border);
            }
            
            .dropdown-header h3 {
                font-size: 1rem;
                font-weight: 600;
            }
            
            .mark-all-read {
                background: none;
                border: none;
                color: var(--primary);
                font-size: 0.75rem;
                cursor: pointer;
            }
            
            .notification-list {
                max-height: 300px;
                overflow-y: auto;
            }
            
            .notification-item {
                display: flex;
                align-items: flex-start;
                gap: 1rem;
                padding: 1rem;
                border-bottom: 1px solid var(--border);
                transition: background-color 0.3s ease;
            }
            
            .notification-item:hover {
                background-color: var(--muted);
            }
            
            .notification-item.unread {
                background-color: var(--primary-light);
            }
            
            .notification-icon {
                width: 36px;
                height: 36px;
                background-color: var(--primary-light);
                color: var(--primary);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1rem;
                flex-shrink: 0;
            }
            
            .notification-content {
                flex: 1;
            }
            
            .notification-content p {
                font-size: 0.875rem;
                margin-bottom: 0.25rem;
            }
            
            .notification-time {
                color: var(--muted-foreground);
                font-size: 0.75rem;
            }
            
            .dropdown-footer {
                padding: 1rem;
                text-align: center;
                border-top: 1px solid var(--border);
            }
            
            .dropdown-footer a {
                color: var(--primary);
                font-size: 0.875rem;
                font-weight: 500;
            }
            
            .dropdown-footer a:hover {
                text-decoration: underline;
            }

            .chart-error {
                text-align: center;
                padding: 2rem;
                color: var(--error);
                font-size: 0.875rem;
            }
        `;
        document.head.appendChild(notificationStyle);
        
        // Mark all as read functionality
        const markAllReadButton = document.querySelector('.mark-all-read');
        markAllReadButton?.addEventListener('click', function() {
            const unreadItems = document.querySelectorAll('.notification-item.unread');
            unreadItems.forEach(item => {
                item.classList.remove('unread');
            });
            
            const badge = document.querySelector('.notifications .badge');
            if (badge) badge.textContent = '0';
        });
    });

    // Close notification dropdown when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.notifications') && notificationDropdown) {
            notificationDropdown.remove();
            notificationDropdown = null;
        }
    });
});