document.addEventListener('DOMContentLoaded', function () {
    const API_URL = '/api';

    const toast = document.querySelector('.toast');
function showToast(message) {
    toast.textContent = message;
    toast.style.display = 'block';
    toast.style.opacity = '1';
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            toast.style.display = 'none';
        }, 300); // Match the animation duration
    }, 3000); // Display for 3 seconds
}

    // Input icon handling
    document.querySelectorAll(".input-with-icon input").forEach(input => {
        const icon = input.closest('.input-with-icon').querySelector('i');
        input.placeholder = input.getAttribute("data-placeholder") || "";

        input.addEventListener("focus", function () {
            if (icon) icon.style.opacity = "0";
            this.dataset.placeholder = this.placeholder;
            this.placeholder = "";
        });

        input.addEventListener("blur", function () {
            if (icon) icon.style.opacity = this.value ? "0" : "1";
            if (!this.value.trim()) {
                this.placeholder = this.dataset.placeholder;
            }
        });

        if (input.value.trim()) {
            if (icon) icon.style.opacity = "0";
        }
    });

    // Password visibility toggle
    document.querySelectorAll('.password-toggle').forEach(toggle => {
        toggle.addEventListener('click', function () {
            const passwordField = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');

            if (passwordField.type === 'password') {
                passwordField.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordField.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    });

    // Password strength meter
    const passwordField = document.getElementById('signup-password');
    if (passwordField) {
        passwordField.addEventListener('input', function () {
            updatePasswordStrength(this.value);
        });
    }

    function updatePasswordStrength(password) {
        const strengthBars = document.querySelectorAll('.strength-bar');
        const strengthText = document.querySelector('.strength-text');

        if (!strengthBars.length || !strengthText) return;

        strengthBars.forEach(bar => {
            bar.className = 'strength-bar';
        });

        let strength = 0;
        if (password.length >= 8) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^A-Za-z0-9]/)) strength++;

        for (let i = 0; i < strength; i++) {
            if (i < strengthBars.length) {
                strengthBars[i].classList.add(
                    strength === 1 ? 'weak' :
                        strength <= 3 ? 'medium' : 'strong'
                );
            }
        }

        const strengthMessages = {
            0: { text: 'Password strength', color: 'var(--muted-foreground)' },
            1: { text: 'Weak password', color: 'var(--error)' },
            2: { text: 'Fair password', color: 'var(--warning)' },
            3: { text: 'Good password', color: 'var(--warning)' },
            4: { text: 'Strong password', color: 'var(--success)' }
        };

        const strengthInfo = strengthMessages[strength];
        strengthText.textContent = strengthInfo.text;
        strengthText.style.color = strengthInfo.color;
    }

    // Form validation and submission
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = {
                firstName: document.getElementById('first-name').value.trim(),
                lastName: document.getElementById('last-name').value.trim(),
                organization: {
                    name: document.getElementById('organization').value.trim(),
                    licenseNumber: document.getElementById('license-number').value.trim()
                },
                email: document.getElementById('signup-email').value.trim(),
                password: document.getElementById('signup-password').value,
                confirmPassword: document.getElementById('confirm-password').value,
                termsAccepted: document.getElementById('terms').checked
            };

            // Validation
            if (!formData.firstName || !formData.lastName ||
                !formData.organization.name || !formData.organization.licenseNumber ||
                !formData.email || !formData.password || !formData.confirmPassword) {
                showToast('Please fill in all fields', 'error');
                return;
            }

            if (!isValidEmail(formData.email)) {
                showToast('Please enter a valid email address', 'error');
                return;
            }

            let passwordStrength = calculatePasswordStrength(formData.password);
            if (passwordStrength < 3) {
                showToast('Please create a stronger password', 'error');
                return;
            }

            if (formData.password !== formData.confirmPassword) {
                showToast('Passwords do not match', 'error');
                return;
            }

            if (!formData.termsAccepted) {
                showToast('Please accept the Terms of Service', 'error');
                return;
            }

            try {
                const response = await fetch(`${API_URL}/users/register`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const data = await response.json();

                if (response.ok) {
                    showToast('Registration successful! Redirecting...', 'success');
                    // Store token
                    localStorage.setItem('token', data.token);
                    if (data.user) {
                        localStorage.setItem('user', JSON.stringify(data.user));
                    }

                    // Make a test request to ensure token works
                    try {
                        const testResponse = await fetch('/dashboard', {
                            headers: {
                                'Authorization': `Bearer ${data.token}`
                            }
                        });

                        if (testResponse.ok) {
                            window.location.href = '/dashboard';
                        } else {
                            throw new Error('Authorization failed');
                        }
                    } catch (error) {
                        console.error('Redirect error:', error);
                        window.location.href = '/dashboard';
                    }
                } else {
                    showToast(data.message || 'Registration failed', 'error');
                }
            } catch (error) {
                console.error('Registration error:', error);
                showToast('Registration failed. Please try again.', 'error');
            }s
        });
    }

    // Helper functions
    function calculatePasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++;
        if (password.match(/[A-Z]/)) strength++;
        if (password.match(/[0-9]/)) strength++;
        if (password.match(/[^A-Za-z0-9]/)) strength++;
        return strength;
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
});