const auth = async (req, res, next) => {
    try {
        let token;
        
        // Check for token in different places
        if (req.header('Authorization')) {
            token = req.header('Authorization').replace('Bearer ', '');
        } else if (req.cookies?.token) {
            token = req.cookies.token;
        } else if (req.query.token) {
            token = req.query.token;
        }

        if (!token) {
            return res.redirect('/login');
        }

        // Verify token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Find user
        const user = await User.findById(decoded.id);
        if (!user) {
            return res.redirect('/login');
        }

        // Add user to request
        req.user = user;
        req.token = token;
        next();
    } catch (error) {
        return res.redirect('/login');
    }
};