const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: true,
        trim: true
    },
    lastName: {
        type: String,
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        lowercase: true
    },
    password: {
        type: String,
        required: true
    },
    organization: {
        name: {
            type: String,
            required: true,
            trim: true
        },
        licenseNumber: {
            type: String,
            required: true,
            unique: true
        },
        address: {
            street: String,
            city: String,
            state: String,
            zipCode: String
        }
    },
    role: {
        type: String,
        enum: ['owner', 'manager', 'staff'],
        default: 'owner'
    },
    settings: {
        notifications: {
            lowStock: { type: Boolean, default: true },
            expiringStock: { type: Boolean, default: true },
            orders: { type: Boolean, default: true }
        },
        rememberMe: { type: Boolean, default: false }
    },
    termsAccepted: {
        type: Boolean,
        required: true
    },
    lastLogin: Date,
    createdAt: {
        type: Date,
        default: Date.now
    }
});

userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 12);
    next();
});

userSchema.methods.matchPassword = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);