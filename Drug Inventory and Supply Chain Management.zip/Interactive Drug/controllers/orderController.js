const Order = require('../models/Order');
const Medicine = require('../models/Medicine');

const orderController = {
    getAllOrders: async (req, res) => {
        try {
            const orders = await Order.find({ owner: req.user._id })
                .populate('supplier', 'name')
                .populate('items.medicine', 'name price');
            res.json({ success: true, data: orders });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    getOrderById: async (req, res) => {
        try {
            const order = await Order.findOne({
                _id: req.params.id,
                owner: req.user._id
            })
            .populate('supplier', 'name contact')
            .populate('items.medicine', 'name price');

            if (!order) {
                return res.status(404).json({ success: false, message: 'Order not found' });
            }

            res.json({ success: true, data: order });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    createOrder: async (req, res) => {
        try {
            const { items, supplier, deliveryDate, notes } = req.body;

            // Calculate total amount
            let totalAmount = 0;
            for (const item of items) {
                const medicine = await Medicine.findById(item.medicine);
                if (!medicine) {
                    return res.status(404).json({ message: `Medicine ${item.medicine} not found` });
                }
                totalAmount += medicine.price * item.quantity;
            }

            const order = await Order.create({
                orderNumber: `ORD-${Date.now()}`,
                owner: req.user._id,
                supplier,
                items,
                totalAmount,
                deliveryDate,
                notes
            });

            res.status(201).json({ success: true, data: order });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    updateOrderStatus: async (req, res) => {
        try {
            const { status } = req.body;
            const order = await Order.findOneAndUpdate(
                { _id: req.params.id, owner: req.user._id },
                { status },
                { new: true }
            )
            .populate('supplier', 'name')
            .populate('items.medicine', 'name price');

            if (!order) {
                return res.status(404).json({ success: false, message: 'Order not found' });
            }

            res.json({ success: true, data: order });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    getPendingOrders: async (req, res) => {
        try {
            const orders = await Order.find({
                owner: req.user._id,
                status: 'pending'
            })
            .populate('supplier', 'name')
            .populate('items.medicine', 'name price');
            res.json({ success: true, data: orders });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    getDeliveredOrders: async (req, res) => {
        try {
            const orders = await Order.find({
                owner: req.user._id,
                status: 'delivered'
            })
            .populate('supplier', 'name')
            .populate('items.medicine', 'name price');
            res.json({ success: true, data: orders });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }
};

module.exports = orderController;