const Medicine = require('../models/Medicine');

const medicineController = {
    getAllMedicines: async (req, res) => {
        try {
            const medicines = await Medicine.find();
            res.json(medicines);
        } catch (error) {
            console.error('Get Medicines Error:', error);
            res.status(500).json({ message: 'Failed to fetch medicines' });
        }
    },

    addMedicine: async (req, res) => {
        try {
            const medicine = new Medicine(req.body);
            await medicine.save();
            res.status(201).json(medicine);
        } catch (error) {
            console.error('Add Medicine Error:', error);
            res.status(500).json({ message: 'Failed to add medicine' });
        }
    },

    updateMedicine: async (req, res) => {
        try {
            const medicine = await Medicine.findByIdAndUpdate(
                req.params.id,
                req.body,
                { new: true }
            );
            if (!medicine) {
                return res.status(404).json({ message: 'Medicine not found' });
            }
            res.json(medicine);
        } catch (error) {
            console.error('Update Medicine Error:', error);
            res.status(500).json({ message: 'Failed to update medicine' });
        }
    },

    deleteMedicine: async (req, res) => {
        try {
            const medicine = await Medicine.findByIdAndDelete(req.params.id);
            if (!medicine) {
                return res.status(404).json({ message: 'Medicine not found' });
            }
            res.json({ message: 'Medicine deleted successfully' });
        } catch (error) {
            console.error('Delete Medicine Error:', error);
            res.status(500).json({ message: 'Failed to delete medicine' });
        }
    },
    // Add this to your existing medicineController
    getMedicineByBarcode: async (req, res) => {
        try {
            const medicine = await Medicine.findOne({ barcode: req.params.barcode });
            if (!medicine) {
                return res.status(404).json({ message: 'Medicine not found' });
            }
            res.json(medicine);
        } catch (error) {
            console.error('Get Medicine By Barcode Error:', error);
            res.status(500).json({ message: 'Failed to fetch medicine' });
        }
    }
};

module.exports = medicineController;