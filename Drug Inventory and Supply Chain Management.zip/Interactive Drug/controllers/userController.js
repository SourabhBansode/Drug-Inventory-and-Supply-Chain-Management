const User = require('../models/User');
const jwt = require('jsonwebtoken');
const config = require('../config/config');

const userController = {
    register: async (req, res) => {
        try {
            const { firstName, lastName, email, password, organization, termsAccepted } = req.body;

            const userExists = await User.findOne({ email });
            if (userExists) {
                return res.status(400).json({ success: false, message: 'Email already registered' });
            }

            const user = await User.create({
                firstName,
                lastName,
                email,
                password,
                organization,
                termsAccepted
            });

            const token = jwt.sign({ id: user._id }, config.JWT_SECRET, {
                expiresIn: config.JWT_EXPIRE
            });

            res.status(201).json({
                success: true,
                token,
                user: {
                    id: user._id,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    email: user.email
                }
            });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    login: async (req, res) => {
        try {
            const { email, password } = req.body;

            const user = await User.findOne({ email });
            if (!user) {
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }

            const isMatch = await user.matchPassword(password);
            if (!isMatch) {
                return res.status(401).json({ success: false, message: 'Invalid credentials' });
            }

            const token = jwt.sign({ id: user._id }, config.JWT_SECRET, {
                expiresIn: config.JWT_EXPIRE
            });

            // Store user data in window.userData
            res.json({
                success: true,
                token,
                user: {
                    id: user._id,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    email: user.email
                },
                script: `<script>window.userData = ${JSON.stringify({
                    id: user._id,
                    firstName: user.firstName,
                    lastName: user.lastName,
                    email: user.email
                })};</script>`
            });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    logout: async (req, res) => {
        try {
            res.json({ success: true, message: 'Logged out successfully' });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },
    
    handleLogout: async (req, res) => {

    },

    getMe: async (req, res) => {
        try {
            const user = await User.findById(req.user._id).select('-password');
            res.json({ success: true, data: user });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    updateMe: async (req, res) => {
        try {
            const { firstName, lastName, email, organization } = req.body;
            const user = await User.findByIdAndUpdate(
                req.user._id,
                { firstName, lastName, email, organization },
                { new: true, runValidators: true }
            ).select('-password');

            res.json({ success: true, data: user });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    updatePassword: async (req, res) => {
        try {
            const { currentPassword, newPassword } = req.body;
            const user = await User.findById(req.user._id);

            const isMatch = await user.matchPassword(currentPassword);
            if (!isMatch) {
                return res.status(401).json({ success: false, message: 'Current password is incorrect' });
            }

            user.password = newPassword;
            await user.save();

            res.json({ success: true, message: 'Password updated successfully' });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }
};

module.exports = userController;