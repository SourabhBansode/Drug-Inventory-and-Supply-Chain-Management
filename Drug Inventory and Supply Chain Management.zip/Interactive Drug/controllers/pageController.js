const Order = require('../models/Order');
const Medicine = require('../models/Medicine');
const Supplier = require('../models/Supplier');

const pageController = {
    getHomePage: function(req, res) {
        res.render('index');
    },

    getLoginPage: function(req, res) {
        res.render('login');
    },

    getSignupPage: function(req, res) {
        res.render('signup');
    },

    getDashboard: function(req, res) {
        const userData = {
            firstName: req.user?.firstName || 'John',
            lastName: req.user?.lastName || 'Doe',
            role: req.user?.role || 'Pharmacy Manager',
            organization: req.user?.organization?.name || 'PharmaFlow'
        };

        res.render('dashboard', { user: userData });
    },

    getInventory: function(req, res) {
        const userData = {
            firstName: req.user?.firstName || 'John',
            lastName: req.user?.lastName || 'Doe',
            role: req.user?.role || 'Pharmacy Manager'
        };

        res.render('inventory', { user: userData });
    },

    getSupplyManagement: function(req, res) {
        const userData = {
            firstName: req.user?.firstName || 'John',
            lastName: req.user?.lastName || 'Doe',
            role: req.user?.role || 'Pharmacy Manager'
        };

        res.render('supplyManagement', { user: userData });
    },

    getOrders: async function(req, res) {
        try {
            const userData = {
                firstName: req.user?.firstName || 'John',
                lastName: req.user?.lastName || 'Doe',
                role: req.user?.role || 'Pharmacy Manager'
            };
    
            // Get all required data
            const [orders, medicines, suppliers] = await Promise.all([
                Order.find()
                    .populate('supplier', 'name')
                    .populate('items.medicine', 'name price'),
                Medicine.find(),
                Supplier.find()
            ]);
    
            const totalItems = orders.length;
            const pendingOrders = orders.filter(order => order.status === 'pending').length;
            const shippedOrders = orders.filter(order => order.status === 'shipped').length;
            const deliveredOrders = orders.filter(order => order.status === 'delivered').length;
    
            const orderStatuses = [
                { value: 'pending', label: 'Pending' },
                { value: 'confirmed', label: 'Confirmed' },
                { value: 'shipped', label: 'Shipped' },
                { value: 'delivered', label: 'Delivered' },
                { value: 'cancelled', label: 'Cancelled' }
            ];
    
            res.render('orders', {
                user: userData,
                orders,
                medicines,  // Add this
                suppliers,  // Add this
                totalOrders: totalItems,
                pendingOrders,
                shippedOrders,
                deliveredOrders,
                orderStatuses
            });
        } catch (error) {
            console.error('Error in getOrders:', error);
            res.status(500).render('error', {
                message: 'Error loading orders page',
                error: error
            });
        }
    },

    getReports: function(req, res) {
        const userData = {
            firstName: req.user?.firstName || 'John',
            lastName: req.user?.lastName || 'Doe',
            role: req.user?.role || 'Pharmacy Manager'
        };

        res.render('reports', { user: userData });
    }
};

// Ensure all methods exist before exporting
Object.keys(pageController).forEach(key => {
    if (typeof pageController[key] !== 'function') {
        throw new Error(`Handler ${key} is not a function`);
    }
});

module.exports = pageController;