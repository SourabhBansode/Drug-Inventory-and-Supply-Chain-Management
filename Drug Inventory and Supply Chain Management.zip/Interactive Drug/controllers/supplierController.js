const Supplier = require('../models/Supplier');

const supplierController = {
    getAllSuppliers: async (req, res) => {
        try {
            const suppliers = await Supplier.find({ owner: req.user._id });
            res.json({ success: true, data: suppliers });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    getSupplierById: async (req, res) => {
        try {
            const supplier = await Supplier.findOne({
                _id: req.params.id,
                owner: req.user._id
            });

            if (!supplier) {
                return res.status(404).json({ success: false, message: 'Supplier not found' });
            }

            res.json({ success: true, data: supplier });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    addSupplier: async (req, res) => {
        try {
            const supplier = new Supplier({
                ...req.body,
                owner: req.user._id,
                status: 'active'
            });
            await supplier.save();
            res.status(201).json({ success: true, data: supplier });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    updateSupplier: async (req, res) => {
        try {
            const supplier = await Supplier.findOneAndUpdate(
                { _id: req.params.id, owner: req.user._id },
                req.body,
                { new: true, runValidators: true }
            );

            if (!supplier) {
                return res.status(404).json({ success: false, message: 'Supplier not found' });
            }

            res.json({ success: true, data: supplier });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    deleteSupplier: async (req, res) => {
        try {
            const supplier = await Supplier.findOneAndDelete({
                _id: req.params.id,
                owner: req.user._id
            });

            if (!supplier) {
                return res.status(404).json({ success: false, message: 'Supplier not found' });
            }

            res.json({ success: true, data: {} });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    },

    updateRating: async (req, res) => {
        try {
            const { score } = req.body;
            const supplier = await Supplier.findOne({
                _id: req.params.id,
                owner: req.user._id
            });

            if (!supplier) {
                return res.status(404).json({ success: false, message: 'Supplier not found' });
            }

            supplier.rating.score = ((supplier.rating.score * supplier.rating.count) + score) / (supplier.rating.count + 1);
            supplier.rating.count += 1;
            await supplier.save();

            res.json({ success: true, data: supplier });
        } catch (error) {
            res.status(500).json({ success: false, message: error.message });
        }
    }
};

module.exports = supplierController;