const express = require('express');
const router = express.Router();
const medicineController = require('../controllers/medicineController');

// Get all medicines
router.get('/', medicineController.getAllMedicines);

// Add a new medicine
router.post('/', medicineController.addMedicine);

// Update a medicine
router.put('/:id', medicineController.updateMedicine);

// Delete a medicine
router.delete('/:id', medicineController.deleteMedicine);

// Get medicine by barcode (you'll need to implement this in your controller)
router.get('/barcode/:barcode', (req, res) => {
    // This is a placeholder - you should implement this in your controller
    res.status(404).json({ message: 'Medicine not found' });
});

module.exports = router;