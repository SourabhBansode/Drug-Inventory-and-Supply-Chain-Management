const express = require('express');
const router = express.Router();
const pageController = require('../controllers/pageController');

// All pages without auth middleware
router.get('/', pageController.getHomePage);
router.get('/login', pageController.getLoginPage);
router.get('/signup', pageController.getSignupPage);
router.get('/dashboard', pageController.getDashboard);
router.get('/inventory', pageController.getInventory);
router.get('/supply-management', pageController.getSupplyManagement);
router.get('/orders', pageController.getOrders);
router.get('/reports', pageController.getReports);

module.exports = router;