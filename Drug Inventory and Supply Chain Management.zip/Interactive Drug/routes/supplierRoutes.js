const express = require('express');
const router = express.Router();
const supplierController = require('../controllers/supplierController');

router.route('/')
    .get(supplierController.getAllSuppliers)
    .post(supplierController.addSupplier);

router.route('/:id')
    .get(supplierController.getSupplierById)
    .put(supplierController.updateSupplier)
    .delete(supplierController.deleteSupplier);

router.put('/:id/rating', supplierController.updateRating);

module.exports = router;