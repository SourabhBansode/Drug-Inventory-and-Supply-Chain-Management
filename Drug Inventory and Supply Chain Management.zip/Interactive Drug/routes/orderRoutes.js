const express = require('express');
const Order = require('../models/Order');  
const router = express.Router();
const orderController = require('../controllers/orderController');

// View route should come first
router.get('/view', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const startIndex = (page - 1) * limit;
        const endIndex = page * limit;

        // Get total count of orders
        const totalItems = await Order.countDocuments();
        
        res.render('orders', {
            startIndex,
            endIndex: Math.min(endIndex, totalItems),
            totalItems,
            currentPage: page,
            totalPages: Math.ceil(totalItems / limit)
        });
    } catch (error) {
        console.error('Error rendering orders page:', error);
        res.status(500).render('error', {
            message: 'Error loading orders page',
            error: error
        });
    }
});

// API routes
router.get('/', orderController.getAllOrders);
router.post('/', orderController.createOrder);

router.route('/:id')
    .get(orderController.getOrderById)
    .put(orderController.updateOrderStatus);

router.get('/pending', orderController.getPendingOrders);
router.get('/delivered', orderController.getDeliveredOrders);

module.exports = router;